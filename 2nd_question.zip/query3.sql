3.SQL> insert into Football_venue values
  2  (
  3  20001,
  4  'France',
  5  10003,
  6  42115
  7  );

--------------------------------------------------



SQL> insert into Football_venue values
  2  (
  3  20002,
  4  'Old Trafford',
  5  10002,
  6  75000
  7  );

---------------------------------------------------

SQL> insert into Football_venue values
  2  (
  3  20003,
  4  'Sanfrasisco',
  5  10004,
  6  60007);

---------------------------------------------------

SQL> insert into Football_venue values
  2  (
  3  20004,
  4  'Amsterdam',
  5  10008,
  6  38048);

-----------------------------------------------------

SQL> insert into Football_venue values
  2  (
  3  20005,
  4  'Brazil',
  5  10005,
  6  78063);

---------------------------------------------------

SQL> insert into Football_venue values
  2  (
  3  20006,
  4  'Quatar',
  5  10009,
  6  45637);

-----------------------------------------------------

SQL> insert into Football_venue values
  2  (
  3  20007,
  4  'Nigeria',
  5  11001,
  6  32009);

---------------------------------------------------

SQL> insert into Football_venue values
  2  (
  3  20008,
  4  'South Korea',
  5  11002,
  6  12345);

----------------------------------------------------

SQL> insert into Football_venue values
  2  (
  3  20009,
  4  'Russia',
  5  12003,
  6  19800);
------------------------------------------------------
SQL> insert into Football_venue values
  2  (
  3  20010,
  4  'Norway',
  5  12007,
  6  56700);