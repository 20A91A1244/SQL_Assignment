4)
select count(*) from Football_venue;