1.SQL> show user;
  USER is "SYSTEM"