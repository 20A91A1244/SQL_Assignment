5)
alter table Football_venue
   2  rename column venue_name to Location;

----------------------------------------------

 alter table Football_venue
  2  rename column capacity to volume;

------------------------------------------------



select Location,volume from Football_venue;
