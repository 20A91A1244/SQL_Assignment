create table Football_venue
  2  (
  3  venue_id number(5),
  4  venue_name varchar2(20),
  5  city_id number(5),
  6  capacity number(5));