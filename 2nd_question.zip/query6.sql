alter table Football_venue
   2  rename column Location to venue_name;


-----------------------------------------------


update Football_venue set venue_name='Australia' where venue_name='France';

---------------------------------------------------------------------------------


delete from Football_venue
  2  where venue_name='Australia';

