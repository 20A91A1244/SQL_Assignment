3)
insert into employee_details values(&a,&b,&c,&d,&e,&f,&g);
Enter value for a: 101
Enter value for b: 'anitha'
Enter value for c: 'manager'
Enter value for d: 0
Enter value for e: '01-jan-20'
Enter value for f: 80000
Enter value for g: 1
------------------------------------------------------------------
insert into employee_details values(&a,&b,&c,&d,&e,&f,&g);
Enter value for a: 102
Enter value for b: 'vasavi'
Enter value for c: 'developer'
Enter value for d: 1
Enter value for e: '01-jan-20'
Enter value for f: 60000
Enter value for g: 1
------------------------------------------------------------------
insert into employee_details values(&a,&b,&c,&d,&e,&f,&g);
Enter value for a: 103
Enter value for b: 'swamy'
Enter value for c: 'developer'
Enter value for d: 1
Enter value for e: '02-jan-20'
Enter value for f: 60000
Enter value for g: 2
------------------------------------------------------------------
insert into employee_details values(&a,&b,&c,&d,&e,&f,&g);
Enter value for a: 104
Enter value for b: 'priyanka'
Enter value for c: 'designer'
Enter value for d: 1
Enter value for e: '11-nov-20'
Enter value for f: 75000
Enter value for g: 2
-------------------------------------------------------------------
insert into employee_details values(&a,&b,&c,&d,&e,&f,&g);
Enter value for a: 105
Enter value for b: 'malik'
Enter value for c: 'anaylst'
Enter value for d: 2
Enter value for e: '03-mar-20'
Enter value for f: 55000
Enter value for g: 3
-------------------------------------------------------------------
 insert into employee_details values(&a,&b,&c,&d,&e,&f,&g);
Enter value for a: 106
Enter value for b: 'aditya'
Enter value for c: 'analyst'
Enter value for d: 2
Enter value for e: '01-feb-20'
Enter value for f: 55000
Enter value for g: 3
-------------------------------------------------------------------
insert into employee_details values(&a,&b,&c,&d,&e,&f,&g);
Enter value for a: 107
Enter value for b: 'samantha
Enter value for c: 'developer'
Enter value for d: 1
Enter value for e: '05-feb-20'
Enter value for f: 60000
Enter value for g: 1
-------------------------------------------------------------------
insert into employee_details values(&a,&b,&c,&d,&e,&f,&g);
Enter value for a: 108
Enter value for b: 'ajay'
Enter value for c: 'designer'
Enter value for d: 2
Enter value for e: '10-apr-20'
Enter value for f: 55000
Enter value for g: 2
--------------------------------------------------------------------
 insert into employee_details values(&a,&b,&c,&d,&e,&f,&g);
Enter value for a: 109
Enter value for b: 'vijay'
Enter value for c: 'developer'
Enter value for d: 1
Enter value for e: '06-may-20'
Enter value for f: 65000
Enter value for g: 1
--------------------------------------------------------------------
insert into employee_details values(&a,&b,&c,&d,&e,&f,&g);
Enter value for a: 110
Enter value for b: 'srikanth'
Enter value for c: 'analyst'
Enter value for d: 2
Enter value for e: '05-jun-20'
Enter value for f: 60000
Enter value for g: 2
--------------------------------------------------------------------
 insert into employee_details values(&a,&b,&c,&d,&e,&f,&g);
Enter value for a: 111
Enter value for b: 'raj'
Enter value for c: 'analyst'
Enter value for d: 2
Enter value for e: '09-jul-20'
Enter value for f: 55000
Enter value for g: 3