1)
create database use Employee