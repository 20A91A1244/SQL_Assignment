5)
select distinct job_name from employee_details;
