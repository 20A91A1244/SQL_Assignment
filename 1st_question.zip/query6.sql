6)
 update employee_details set salary=70000 where emp_name='raj';
