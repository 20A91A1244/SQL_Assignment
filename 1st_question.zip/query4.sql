4)
select salary from employee_details;